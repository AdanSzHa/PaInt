package com.androidplot.xy;

import com.androidplot.ui.*;

/**
 * Created by halfhp on 10/6/16.
 */
public class XYSeriesBundle extends SeriesBundle<XYSeries, XYSeriesFormatter> {

    public XYSeriesBundle(XYSeries series, XYSeriesFormatter formatter) {
        super(series, formatter);
    }
}
