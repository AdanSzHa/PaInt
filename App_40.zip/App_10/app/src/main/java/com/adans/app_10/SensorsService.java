package com.adans.app_10;

import android.app.Service;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;

import java.util.List;

public class SensorsService extends Service implements SensorEventListener{


    private final IBinder cBinder = new SensBinder();


    float VAX, VAY, VAZ, VGX, VGY, VGZ;


    @Override
    public void onCreate (){
        super.onCreate();


        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        List<Sensor> listaSensores = sensorManager.getSensorList(Sensor.TYPE_ALL);

        listaSensores = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER);

        if (!listaSensores.isEmpty()) {
            Sensor acelerometerSensor = listaSensores.get(0);
            sensorManager.registerListener(this, acelerometerSensor,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }

        listaSensores = sensorManager.getSensorList(Sensor.TYPE_GYROSCOPE);

        if (!listaSensores.isEmpty()) {
            Sensor giroscopioSensor = listaSensores.get(0);
            sensorManager.registerListener(this, giroscopioSensor,
                    SensorManager.SENSOR_DELAY_NORMAL);
        }

    }
    public class SensBinder extends Binder {
        SensorsService getService() {return SensorsService.this;}
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return cBinder;
    }


    @Override
    public void onSensorChanged(SensorEvent event) {
        synchronized (this) {
            switch (event.sensor.getType()) {

                case Sensor.TYPE_ACCELEROMETER:
                    VAX = event.values[0];
                    VAY = event.values[1];
                    VAZ = event.values[2];

                    break;

                case Sensor.TYPE_GYROSCOPE:
                    VGX = event.values[0];
                    VGY = event.values[1];
                    VGZ = event.values[2];

                    break;
            }
        }

    }

    public float getVAX() {
        return VAX;
    }

    public float getVAY() {
        return VAY;
    }

    public float getVAZ() {
        return VAZ;
    }

    public float getVGX() {
        return VGX;
    }

    public float getVGY() {
        return VGY;
    }

    public float getVGZ() {
        return VGZ;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
